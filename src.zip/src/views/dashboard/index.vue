<template>
  <div>
    <!-- <UploadImage @onSuccess="onSuccess1"></UploadImage>
    <UploadImage @onSuccess="onSuccess2"></UploadImage> -->
  </div>
</template>

<script>
export default {
  data() {
    return {}
  },

  created() {},

  methods: {}
}
</script>

<style scoped></style>
