// 通用
export default {
  // 启用状态
  enableState: [
    {
      id: '1',
      value: '启用'
    },
    {
      id: '0',
      value: '禁用'
    }
  ],
  // 有无
  hasState: [
    {
      id: '1',
      value: '有'
    },
    {
      id: '0',
      value: '无'
    }
  ]
}

