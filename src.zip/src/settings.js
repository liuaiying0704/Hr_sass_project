module.exports = {
// 网站标题,修改重新起服务
  title: 'hrhass',

  /**
   * @type {boolean} true | false
   * @description Whether fix the header
   */
  fixedHeader: false,

  /**
   * @type {boolean} true | false
   * @description Whether show the logo in sidebar
   */
  // 左侧logo
  sidebarLogo: true
}
